/**
 * Round-trip tests for JSON, YAML, TOML, CSV.
 *
 * Parsers return plain JS values. Serializers take (value, opts).
 * We test that value → format → value round-trips losslessly.
 */
'use strict';

const OPTS = { jsonIndent: 2, yamlIndent: 2 };

test('JSON round-trip: simple object', (ctx) => {
  const input = { name: 'Tooly', version: '1.2', tools: ['compress', 'json'] };
  const json = ctx.SERIALIZERS.json(input, OPTS);
  const back = ctx.PARSERS.json(json);
  assert.eq(back, input, 'JSON round-trip lost data');
});

test('JSON parse: strict JSON works', (ctx) => {
  const input = '{"name":"Tooly","count":11}';
  const out = ctx.PARSERS.json(input);
  assert.eq(out.name, 'Tooly');
  assert.eq(out.count, 11);
});

test('YAML round-trip: simple object', (ctx) => {
  const input = { name: 'Tooly', tools: ['compress', 'json'] };
  const yaml = ctx.SERIALIZERS.yaml(input, OPTS);
  const back = ctx.PARSERS.yaml(yaml);
  assert.eq(back, input);
});

test('TOML round-trip: flat object', (ctx) => {
  const input = { port: 8080, host: 'localhost', enabled: true };
  const toml = ctx.SERIALIZERS.toml(input, OPTS);
  const back = ctx.PARSERS.toml(toml);
  assert.eq(back, input);
});

test('Cross-format: JSON -> YAML -> JSON preserves structure', (ctx) => {
  const input = '{"name":"Tooly","version":"1.2","tags":["tool","web"]}';
  const parsed1 = ctx.PARSERS.json(input);
  const yaml = ctx.SERIALIZERS.yaml(parsed1, OPTS);
  const parsed2 = ctx.PARSERS.yaml(yaml);
  const jsonBack = ctx.SERIALIZERS.json(parsed2, OPTS);
  assert.eq(JSON.parse(jsonBack), JSON.parse(input));
});

test('Cross-format: JSON -> TOML -> JSON preserves flat object', (ctx) => {
  const input = { port: 8080, host: 'localhost', enabled: true };
  const toml = ctx.SERIALIZERS.toml(input, OPTS);
  const parsed = ctx.PARSERS.toml(toml);
  assert.eq(parsed, input);
});

test('CSV serialize: array of objects produces header + rows', (ctx) => {
  const input = [
    { name: 'Image Smusher', category: 'image' },
    { name: 'JSON Fixer', category: 'dev' },
  ];
  const csv = ctx.SERIALIZERS.csv(input, OPTS);
  assert.contains(csv, 'name,category');
  assert.contains(csv, 'Image Smusher');
  assert.contains(csv, 'JSON Fixer');
});
