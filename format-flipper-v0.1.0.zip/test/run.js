#!/usr/bin/env node
/**
 * Format Flipper test runner — zero dependencies, just Node.
 *
 * Extracts the parser/serializer code from index.html and runs round-trip +
 * cross-format tests against it. This way tests exercise the actual shipped
 * code, not a copy that could drift.
 *
 * Usage:
 *   node test/run.js           # run all tests
 *   node test/run.js json      # run only tests in json.test.js
 */
'use strict';

const fs = require('fs');
const path = require('path');

// --- Extract tool JS from index.html ------------------------------------
function loadTool() {
  const htmlPath = path.join(__dirname, '..', 'index.html');
  const html = fs.readFileSync(htmlPath, 'utf8');

  // Collect all <script> blocks that are NOT application/ld+json and NOT src=
  const scriptRe = /<script(?![^>]*application\/ld)(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/g;
  const blocks = [];
  let m;
  while ((m = scriptRe.exec(html)) !== null) {
    if (m[1].trim().length > 100) blocks.push(m[1]);
  }

  // Strip the outer IIFE wrapper `(function() { 'use strict'; ... })();` from
  // the main tool block so `const PARSERS = ...` becomes a context-level
  // declaration visible to subsequent extraction.
  const unwrapped = blocks.map(b => {
    const iifeMatch = b.match(/^\s*\(function\(\)\s*\{\s*(?:'use strict';)?\s*([\s\S]*?)\s*\}\)\s*\(\s*\)\s*;?\s*$/);
    return iifeMatch ? iifeMatch[1] : b;
  });

  return unwrapped.join('\n;\n');
}

// --- Test framework -----------------------------------------------------
const tests = [];
const only = process.argv[2];
let passed = 0, failed = 0;

global.test = (name, fn) => tests.push({ name, fn });
global.assert = {
  eq(actual, expected, msg = '') {
    const a = JSON.stringify(actual);
    const b = JSON.stringify(expected);
    if (a !== b) {
      throw new Error(`${msg || 'assert.eq failed'}\n  expected: ${b}\n  got:      ${a}`);
    }
  },
  contains(haystack, needle, msg = '') {
    if (!haystack.includes(needle)) {
      throw new Error(`${msg || 'assert.contains failed'}\n  expected string to include: ${JSON.stringify(needle)}\n  got: ${JSON.stringify(haystack)}`);
    }
  },
  throws(fn, msg = '') {
    let threw = false;
    try { fn(); } catch (e) { threw = true; }
    if (!threw) throw new Error(msg || 'expected function to throw');
  },
};

// --- Load tool + run tests ----------------------------------------------
const toolCode = loadTool();
// Make parsers/serializers available on a sandbox global.
// This is a blunt instrument, but correct for our single-file architecture.
const vm = require('vm');
const sandbox = { console, setTimeout, clearTimeout, document: null, window: null };
sandbox.window = sandbox;
// Stub out DOM-touching functions the tool expects at load time
sandbox.document = {
  addEventListener: () => {},
  querySelector: () => null,
  querySelectorAll: () => [],
  getElementById: () => null,
  createElement: () => ({ style: {}, addEventListener: () => {}, classList: { add: () => {}, remove: () => {} } }),
  body: { appendChild: () => {} },
};
try {
  vm.createContext(sandbox);
  // Create a stub element that handles all the common DOM operations
  const makeStubEl = () => {
    const el = {
      style: {}, value: '', textContent: '', innerHTML: '',
      classList: { add: () => {}, remove: () => {}, toggle: () => {}, contains: () => false },
      dataset: {}, attributes: [], children: [],
      addEventListener: () => {}, removeEventListener: () => {},
      appendChild: () => {}, removeChild: () => {}, setAttribute: () => {},
      getAttribute: () => null, hasAttribute: () => false,
      click: () => {}, focus: () => {}, blur: () => {},
      querySelector: () => makeStubEl(), querySelectorAll: () => [],
      getBoundingClientRect: () => ({ top: 0, left: 0, width: 0, height: 0 }),
    };
    return el;
  };
  sandbox.document.querySelector = () => makeStubEl();
  sandbox.document.querySelectorAll = () => [];
  sandbox.document.getElementById = () => makeStubEl();
  sandbox.document.createElement = () => makeStubEl();
  sandbox.document.body = makeStubEl();
  sandbox.document.documentElement = makeStubEl();
  sandbox.document.head = makeStubEl();
  sandbox.navigator = { clipboard: { writeText: () => Promise.resolve() }, userAgent: 'node-test' };
  sandbox.location = { hash: '', search: '', pathname: '/', href: 'http://test/' };
  sandbox.history = { replaceState: () => {}, pushState: () => {} };
  sandbox.URL = URL;
  sandbox.URLSearchParams = URLSearchParams;
  sandbox.Blob = class Blob { constructor(parts) { this.parts = parts; } };
  sandbox.File = class File {};
  sandbox.FileReader = class FileReader {};
  vm.runInContext(toolCode, sandbox, { filename: 'tool.js' });
  // `const PARSERS = ...` doesn't auto-attach to globalThis, so extract explicitly.
  const exported = vm.runInContext(
    '({ PARSERS: typeof PARSERS !== "undefined" ? PARSERS : null, SERIALIZERS: typeof SERIALIZERS !== "undefined" ? SERIALIZERS : null })',
    sandbox
  );
  sandbox.PARSERS = exported.PARSERS;
  sandbox.SERIALIZERS = exported.SERIALIZERS;
  if (!sandbox.PARSERS || !sandbox.SERIALIZERS) {
    throw new Error('PARSERS/SERIALIZERS not found in tool code');
  }
} catch (e) {
  console.error('  ✗ failed to load tool code:', e.message);
  process.exit(1);
}

// Discover test files
const testDir = __dirname;
const testFiles = fs.readdirSync(testDir).filter(f => f.endsWith('.test.js'));

for (const f of testFiles) {
  if (only && !f.startsWith(only)) continue;
  require(path.join(testDir, f));
}

// Run tests
console.log(`\n  running ${tests.length} tests\n`);
for (const t of tests) {
  try {
    t.fn(sandbox);
    console.log(`  \x1b[32m✓\x1b[0m ${t.name}`);
    passed++;
  } catch (e) {
    console.log(`  \x1b[31m✗\x1b[0m ${t.name}`);
    console.log(`    ${e.message.split('\n').join('\n    ')}`);
    failed++;
  }
}

console.log(`\n  ${passed}/${tests.length} passed${failed ? `, \x1b[31m${failed} failed\x1b[0m` : ''}\n`);
process.exit(failed ? 1 : 0);
